﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lr5
{
    class MyList : List<Phone>
    {

        public void Edit(MyList lst)
        {
            int index;
            Console.WriteLine("Введите индекс изменяемого объекта: ");
            index = Convert.ToInt32(Console.ReadLine());
            string input1;

            Console.WriteLine("Введите телефон, ФИО владельца, дату, тариф, минуты:\n");

            input1 = Console.ReadLine();

            string[] separators = { ", " };
            string[] words = input1.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            Phone novyi = new Phone(words[0], words[1], words[2], words[3], words[4]);
            lst[index] = novyi;
        }

        public override string ToString()
        {
            string str = "";
            for (int i = 0; i < Count; i++)
                str += this[i] + "\n";
            return str;
        }
    }
}
