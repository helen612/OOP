﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    public class Republic : Country
    {
        public string state_name { get; set; }
        public int year_found { get; set; }
        public Republic() : base()
        {
            state_name = "NULL";
			year_found = 0;
        }
        public Republic(string state_name, int year_found, string gover_form, string cap_name) : base(gover_form, cap_name)
        {
            this.state_name = state_name;
            this.year_found = year_found;
        }
        public override string ToString()
        {
            return base.ToString() + string.Format($"\nНазвание Республики: {state_name}\nГод основания: {year_found}");
        }
        public override bool Equals(object obj)
        {
            if (obj == null || !this.GetType().Equals(obj.GetType())) return false;
            Republic c = (Republic)obj;
            return base.Equals(obj) && this.state_name == c.state_name && this.year_found == c.year_found;
        }
    }
}
