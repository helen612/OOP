﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Program
    {
        public static void Main(string [] args)
        {
            Country [] a = new Country[3];
            a[0] = new Republic("Республика Беларусь", 1919, "Респубика", "Минск");
            a[1] = new Kingdom("Великобритания","Королева", "Королевство","Лондон");
            a[2] = new Monarchy("Австралия", "Королева", "Конституционная монархия", "Канберра");

            Console.Write("Вывод всех записей:\n");
            foreach (Country o in a)
            {
                Console.WriteLine(o);
            }
        }
    }
}
