﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    public class Monarchy : Country
    {
		public string state { get; set; }
        public string monarchs { get; set; }
        public Monarchy() : base()
        {
			state = "NULL";
			monarchs = "NULL";
        }
        public Monarchy(string state, string monarchs, string gover_form, string cap_name) : base(gover_form, cap_name)
        {
			this.state = state;
            this.monarchs = monarchs;
        }
        public override string ToString()
        {
            return base.ToString() + string.Format($"\nСтрана: {state}\nМонарх: {monarchs}");
        }
        public override bool Equals(object obj)
        {
            if (obj == null || !this.GetType().Equals(obj.GetType())) return false;
            Monarchy c = (Monarchy)obj;
            return base.Equals(obj) && this.monarchs == c.monarchs && this.state == c.state;
        }
    }
}
