﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    public class Kingdom : Country
    {
        public string state_name { get; set; }
        public string state_head { get; set; }
        public Kingdom() : base()
        {
            state_name = "NULL";
            state_head = "NULL";
        }
        public Kingdom(string state_name, string capital, string gover_form, string cap_name) : base(gover_form, cap_name)
        {
            this.state_name = state_name;
			this.state_head = capital;
        }
        public override string ToString()
        {
            return base.ToString() + string.Format($"\nНазвание Государства: {state_name}\nГлава: {state_head}\n");
        }
        public override bool Equals(object obj)
        {
            if (obj == null || !this.GetType().Equals(obj.GetType())) return false;
            Kingdom c = (Kingdom)obj;
			return base.Equals(obj) && this.state_name == c.state_name && this.state_head == c.state_head;
        }
    }
}
