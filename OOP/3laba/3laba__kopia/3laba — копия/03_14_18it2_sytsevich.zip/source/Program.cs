﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace lab3
{


    class Program
    {
        

        static void Main(string[] args)
        {
            Region_list list = new Region_list();
            Mechanizm obj = new Mechanizm("Пластик", "Красный", "Зубчатый", "EcoForm", 101);
            Unit obj2 = new Unit("Древесина", "Желтый", 7, "Средний");
            Detail obj7 = new Detail("Алюминий", "Бирюзовый", 20, "Cредний", "В часах", "Албания", 99);
            Unit obj3 = new Unit("Металл", "Оранжевый", 13, "Маленький");
            Mechanizm obj4 = new Mechanizm("Эко-пластик", "Желтый", "Гидравлический", "SichCompany", 98);
            Detail obj5 = new Detail("Металл", "Черный", 5, "Большой", "В технике", "Япония", 1001);
           
            Detail obj6 = new Detail("Алюминий", "Желтый", 20, "Cредний", "В часах", "Хорватия", 1000);
            


            list.Add(obj);
            list.Add(obj2);
            list.Add(obj3);
            list.Add(obj4);
            list.Add(obj5);
            list.Add(obj6);
            list.Add(obj7);
            
            Console.WriteLine(list.ToString());
            Console.WriteLine(" ");
            Console.WriteLine("Сортировка:");
            list.Sort();
            Console.WriteLine(list.ToString());
            Console.WriteLine(" ");
            Console.WriteLine("Удаление 4 элемента:");
            list.RemoveAt(3);
            Console.WriteLine(list.ToString());
            Console.WriteLine(" ");
            Console.WriteLine("Отчистить все данные:");
            list.Clear();
            Console.WriteLine(list.ToString());
            Console.WriteLine("ПУсто)");



            Console.ReadLine();

        }
    }
}