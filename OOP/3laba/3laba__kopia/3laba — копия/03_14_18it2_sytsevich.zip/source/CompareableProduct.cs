﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab3
{
    interface CompareableProduct
    {
        int Compare(Product o);
    }
}
